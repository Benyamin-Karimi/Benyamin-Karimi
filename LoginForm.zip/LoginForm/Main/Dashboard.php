<?php 
    session_start(); 
    $Message = $_SESSION["username"]." خوش آمدید ";
    echo("<h2 dir='rtl'>$Message</h2>"); 
?>
