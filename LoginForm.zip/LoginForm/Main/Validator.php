<?php
    $UserName = $_POST["username"];
    $Password = $_POST["password"];

    $UserNameOnDatabase = "Benyamin";
    $PasswordOnDatabase = "*Karimi";
    if ($UserName == $UserNameOnDatabase && $Password == $PasswordOnDatabase) 
    {
        header("Location: Dashboard.php");
        session_start(); 
        $_SESSION["username"] = $UserName;
        exit();
    } 
    else
    {
        header("Location: ..\Index.php?error=1");
        exit();
    }
?>