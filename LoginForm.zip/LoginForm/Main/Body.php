<body>
    <div class="container">
        <form action="./Main/Validator.php" method="post" class="login-form">
            <h2>ورود به حساب کاربری</h2>
            <label for="username">نام کاربری</label>
            <input type="text" name="username" placeholder="نام کاربری خود را وارد کنید" required>
            <label for="password">رمز عبور</label>
            <input type="password" name="password" placeholder="رمز عبور خود را وارد کنید" required>
            <button type="submit">ورود</button>
            <label id="error">نام کاربری یا رمز عبور اشتباه است</label>
        </form>
    </div>
</body>
<script src="./JavaScript/Script.js"></script>