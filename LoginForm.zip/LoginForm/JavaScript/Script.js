if(new URLSearchParams(window.location.search).has('error'))
{
    document.getElementById("error").style.display = 'block';
}