
<html>
    <?php include(".\Main\Header.php"); ?>
    <?php include(".\Main\Body.php"); ?>
</html>